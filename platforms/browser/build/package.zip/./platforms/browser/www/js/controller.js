//*********************************//
//GLOBAL VARIABLES
//*********************************//
var db;
var uid; //user id
var auth;

$(document).ready(function(){

    db = firebase.database();
    auth = firebase.auth();
    console.log(db);

    //*********************************//
    //EVENT HANDLERS
    //*********************************//

    //show dashboard panel
   $( document ).on( "swiperight", "#dashboard", function( e ) {
        if ( $( ".ui-page-active" ).jqmData( "panel" ) !== "open" ) {
            $( "#mainpanel" ).panel( "open" );
        }
    });

    

    //*********************************//
    //INTERACTIONS
    //*********************************//

    $("#loginBtn").click(function(){
        $.mobile.loading("show");
        var email=$("#email").val();
        var password = $("#password").val();
        firebase.auth().signOut();
        firebase.auth().signInWithEmailAndPassword(email, password).then(function(user){
            console.log(firebase.auth().currentUser.email);
            $("#currentEmail").html(firebase.auth().currentUser.email);
            $.mobile.navigate("#dashboard");
            uid = firebase.auth().currentUser.uid;
            loadTaskNames();
            loadTasks();
            if(firebase.auth().currentUser.uid=="OTnpSjeTD7ezIVIZ7e9vmXsHBK52"){
                $(".adminonly").show();
            }else{
                $(".adminonly").hide();
            }
            $.mobile.loading("hide");
        }).catch(function(error) {
            // Handle Errors here.
            var errorCode = error.code;
            var errorMessage = error.message;
            alert(errorMessage);
            $.mobile.loading("hide");
        });
    });

    $("#taskpush").click(function(){
        var ref = db.ref("tasknames");
        var task = $("#pushtask").val();
        var desc = $("#pushdesc").val();
        ref.push({
            task: task,
            desc:desc
        }).then(function(){
            console.log("PUSH");
            $("#pushtask").val("");
            $("#pushdesc").val("");
        });
    });

    $("#logout").click(function(){
        firebase.auth().signOut();
        $.mobile.navigate("#login");
    });

    $("#quit").click(function(){
        navigator.app.exitApp();
    });

    $("#addTaskButton").click(function(){
        $("#tasknames li").addClass("ui-screen-hidden").each(function(){
            $(this).click(function(){
                var value=$(this).find("a").attr("data-desc");
                var ts = $(this).find("a").html();
                console.log($(this));
                $("#taskdesc").val(value);
                $("#taskname").val(ts);
                $("#tasknames li").addClass("ui-screen-hidden");
            });
        });
        
    });

    $(document).on("pagebeforeshow","#users",function(){
        loadUsers();
    });

    $(document).on("pagebeforeshow","#addtask",function(){
        loadUserList();
    });

    $(document).on("pagebeforeshow","#records",function(){
        loadHerd();
    });

    $("#addUserButton").click(function(){
        $("#addusername").val("");
        $("#adduseremail").val("");
        $("#adduserpassword").val("");
        $("#adduserconfirm").val("");
    });

    $("#saveuser").click(function(){
        if($("#adduserconfirm").val()==$("#adduserpassword").val()){
            var email = $("#adduseremail").val() + "@myswine.com";
            var password = $("#adduserpassword").val();
            var xname = $("#addusername").val();
            auth.createUserWithEmailAndPassword(email,password).catch(function(e){
                alert(e.message);
            }).then(function(e){
                console.log(e.uid);
                db.ref("users").push({
                    name: xname,
                    uid: e.uid,
                    email: email
                }).then(function(){
                    loadUsers();
                    window.history.back();
                });
            });
        }
        else{
            alert("Password mismatch");
        }
    });

    $("#savepig").click(function(){
        var pname = $("#addpigname").val();
        var pgender = $("#addpiggender").val();
        var pbdate = $("#addpigbdate").val();
        db.ref("herd").push({
            name: pname,
            gender: pgender,
            birthdate: pbdate,
            status: "ACTIVE"
        }).then(function(){
            alert("Record saved");
            $.mobile.navigate("#records");
        });
    });

    $("#qrsearch").click(function(){
        cordova.plugins.barcodeScanner.scan(function(result){
            alert(result.text);
        });
    });

    $("#deleteuser").click(function(){
        if(confirm("Are you sure?")){
            var uid = $("#edituserid").val();
            var key;
            var userref = db.ref("users");
            userref.orderByChild("uid").equalTo(uid).on("child_added",function(snap){
                key = snap.key;
                db.ref("users/" + key).remove().then(function(){
                    alert("Deleting user account must be done on Firebase Authentication Module");
                    $.mobile.navigate("#users");
                    window.open("https://myswine-90d52.firebaseio.com/")
                });
            });
        }
    });

    $("#savetask").click(function(){
        var taskname = $("#taskname").val();
        var taskdesc = $("#taskdesc").val();
        var taskassigned = $("#taskassigned").val();
        addFireTask(taskname,taskdesc,taskassigned);
    });




});

//USER-DEFINED FUNCTIONS
function isEmail(email) {
  var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
  return regex.test(email);
}

function loadTasks(){
    uid = firebase.auth().currentUser.uid;
   var taskRef = db.ref("tasks");
   var cur=0;
   var fin=0;
   $("#curCount").html(cur);
   $("#finCount").html(cur);

   $("#currentTasks").html("");
   $("#finishedTasks").html("");
   taskRef.orderByChild("assigned").equalTo(uid).on("child_added", function(data){
    console.log(data.key);
    if(data.val().status=="CURRENT"){
        $("#currentTasks").prepend("<li><a href='#'><h1>" + data.val().task + "</h1><p>" + data.val().desc + "</p></a></li>").listview("refresh");
        cur++;
        $("#curCount").html(cur);
    }else{
        fin++;
        $("#finCount").html(cur);
    }
   });
}

function loadTaskNames(){
    var tasknameref = db.ref("tasknames");
    tasknameref.orderByChild("task").on("child_added",function(data){
        $("#tasknames").append("<li><a href='#' data-desc='" + data.val().desc + "'>" + data.val().task + "</a></li>").listview("refresh");
    });
}

function loadUsers(){
    $("#userlist").html("");
    var userref = db.ref("users");
    userref.orderByChild("name").on("child_added",function(data){
        $("#userlist").append("<li><a href='#userinfo' data-uid='" + data.val().uid + "'><h4>" + data.val().name + "</h4><p>" + data.val().email + "</p></a></li>").listview("refresh");
        $("#userlist li").each(function(){
            $(this).click(function(){
                var uid = $(this).find("a").attr("data-uid");
                var email = $(this).find("a").find("p").html();
                //email = email.substring(0,email.indexOf("@"));
                var xname = $(this).find("a").find("h4").html();
                $("#edituserid").val(uid);
                $("#editusername").val(xname);
                $("#edituseremail").val(email);
                $("#edituserpassword").val("");
                $("#edituserconfirm").val("");
            });
        });
    });
}

function loadHerd(){
    var herdref = db.ref("herd");
    var key;
    var name;
    var gender;
    var ago;
    var birthdate;
    $("#piglist").html("");
    herdref.orderByChild("name").on("child_added",function(data){
        key = data.key;
        name = data.val().name;
        gender = data.val().gender;
        birthdate = data.val().birthdate;
        ago = moment(birthdate,"YYYY-MM-DD").fromNow();
        ago = ago.substring(0,ago.indexOf("ago"));
        $("#piglist").append("<li><a href='#' data-key='" + key + "'><h4>" + name + "</h4><p>[" + gender + "] " + ago + "[" + birthdate + "]</p></a></li>").listview("refresh");
        //attach handler EACH
    });
}

function loadUserList(){
    $("#taskassigned").html("");
    var userref = db.ref("users");
    userref.orderByChild("name").on("child_added",function(data){
        $("#taskassigned").append("<option value='" + data.val().uid + "'>" + data.val().name + "</option>").select("refresh");
    })
}

function attachHandlers(){
    $("#userlist li").each(function(){
        $(this).click(function(){
            console.log("click");
            var uid = $(this).find("a").attr("data.uid");
            var email = $(this).find("a").find("p").html();
            email = email.substring(0,email.indexOf("@"));
            var xname = $(this).find("a").find("h4").html();
            $("#editusername").val(uid);
            $("#editusername").val(xname);
            $("#edituseremail").val(email);
            $("#edituserpassword").val("");
            $("#edituserconfirm").val("");
            $.mobile.navigate("#userinfo");
        });
    });
}

function addFireTask(taskName,description,assignedTo){
    var taskRef = db.ref("tasks");
    var timeStamp = new Date();
    timeString = changeFormat(timeStamp);
    taskRef.push({
        task: taskName,
        desc: description,
        assigned: assignedTo,
        created: timeString,
        finished: "NONE",
        status: "CURRENT"
    }).then(function(e){
        console.log(e);
        alert("New task created");
        $.mobile.navigate("#tasks");
    });
}

function addNewTaskName(task,desc){
    var tasknameref = db.ref("tasknames");
    tasknameref.push({
        task:task,
        desc:desc
    });
}

function changeFormat(datevalue){
    return (parseInt(datevalue.getFullYear())+1) + "-" + datevalue.getMonth() + "-" + datevalue.getDate() + " " + datevalue.getHours() + ":" + datevalue.getMinutes() + ":" + datevalue.getSeconds();
}